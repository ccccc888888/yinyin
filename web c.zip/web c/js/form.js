/* Student form validation and submission */
const FORM_KEY = "yin_yin_student_form";

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("studentForm");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    const name = form.studentName.value.trim();
    const studentId = form.studentId.value.trim();
    const genderOption = form.querySelector('input[name="gender"]:checked');
    const gender = genderOption ? genderOption.value : "Rather Not Say";
    const subject = form.subject.value;
    const remark = form.remark.value.trim();

    toggleError("errName", name.length > 0);
    toggleError("errId", studentId.length > 0);
    toggleError("errSubject", subject.length > 0);
    if (!name || !studentId || !subject) return;

    const studentData = {
      name: name,
      sid: studentId,
      gender: gender,
      subject: subject,
      remark: remark || "None"
    };
    localStorage.setItem(FORM_KEY, JSON.stringify(studentData));
    window.location.href = form.action;
  });

  form.addEventListener("reset", function () {
    ["errName", "errId", "errSubject"].forEach(function (id) {
      toggleError(id, false);
    });
  });
});

function toggleError(id, show) {
  const element = document.getElementById(id);
  if (element) element.style.display = show ? "block" : "none";
}
