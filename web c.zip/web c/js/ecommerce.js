/* Custom clothing order calculation */
function getSelectedOption(name) {
  return document.querySelector('input[name="' + name + '"]:checked');
}

function calculateTotal() {
  const shirt = getSelectedOption("shirt");
  const design = getSelectedOption("design");
  let total = 0;
  let shirtText = "Not selected";
  let designText = "Not selected";

  if (shirt) {
    const shirtPrice = Number(shirt.getAttribute("data-price")).toFixed(2);
    total = total + Number(shirtPrice);
    shirtText = shirt.value + " — RM " + shirtPrice;
  }

  if (design) {
    const designPrice = Number(design.getAttribute("data-price")).toFixed(2);
    total = total + Number(designPrice);
    designText = design.value + " — RM " + designPrice;
  }

  const embroiderySelected = document.getElementById("embroidery").checked;
  const logoSelected = document.getElementById("logo").checked;
  if (embroiderySelected) total = total + Number(Number(15).toFixed(2));
  if (logoSelected) total = total + Number(Number(25).toFixed(2));

  total = Number(total.toFixed(2));
  document.getElementById("customPrice").textContent = "RM " + total.toFixed(2);

  const rows = [
    ["Shirt", shirtText],
    ["Design", designText],
    ["Embroidery", embroiderySelected ? "RM 15.00" : "Not included"],
    ["Logo", logoSelected ? "RM 25.00" : "Not included"]
  ];
  let table = "<table class=\"custom-order-table\"><tbody>";
  rows.forEach(function (row) {
    table += "<tr><th>" + row[0] + "</th><td>" + row[1] + "</td></tr>";
  });
  table += "</tbody></table>";
  document.getElementById("customOrderDetails").innerHTML = table;
  document.getElementById("customSummaryTotal").textContent = "RM " + total.toFixed(2);
  return total;
}

function totalPayment() {
  const shirt = getSelectedOption("shirt");
  const design = getSelectedOption("design");
  if (!shirt || !design) {
    alert("Please select a shirt and a design before continuing.");
    return;
  }

  const subtotal = calculateTotal();
  let discount = 0;
  if (subtotal > 150) {
    discount = Number((subtotal * 0.10).toFixed(2));
    alert("Congratulations! Your order is eligible for a 10% discount.");
  } else {
    alert("Thank you for your purchase!");
  }

  const finalTotal = Number((subtotal - discount).toFixed(2));
  const order = {
    shirt: shirt.value,
    shirtPrice: Number(Number(shirt.getAttribute("data-price")).toFixed(2)),
    design: design.value,
    designPrice: Number(Number(design.getAttribute("data-price")).toFixed(2)),
    embroidery: document.getElementById("embroidery").checked,
    logo: document.getElementById("logo").checked,
    subtotal: subtotal,
    discount: discount,
    total: finalTotal
  };
  localStorage.setItem("yin_yin_custom_order", JSON.stringify(order));
  window.location.href = "order-confirmation.html";
}

document.addEventListener("DOMContentLoaded", function () {
  const shirtOptions = document.querySelectorAll('input[name="shirt"]');
  const designOptions = document.querySelectorAll('input[name="design"]:not(:disabled)');
  let selectedShirt = null;
  let selectedDesign = null;

  shirtOptions.forEach(function (option) {
    option.addEventListener("click", function () {
      if (selectedShirt === option) {
        option.checked = false;
        selectedShirt = null;
      } else {
        selectedShirt = option;
      }
      calculateTotal();
    });
  });

  designOptions.forEach(function (option) {
    option.addEventListener("click", function () {
      if (selectedDesign === option) {
        option.checked = false;
        selectedDesign = null;
      } else {
        selectedDesign = option;
      }
      calculateTotal();
    });
  });

  document.getElementById("embroidery").addEventListener("change", calculateTotal);
  document.getElementById("logo").addEventListener("change", calculateTotal);
  document.getElementById("customOrderBtn").addEventListener("click", totalPayment);
  calculateTotal();
});
